import Component from '@glimmer/component';

export default class MyApp03 extends Component {

}
